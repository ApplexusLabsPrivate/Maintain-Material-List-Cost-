sap.ui.define([
	"Ingles/Mock/MassListCost/test/unit/controller/View1.controller"
], function () {
	"use strict";
});